<?php
    require_once('functions/function.php');
    needLogged();
		$name=$_SESSION['username'];
	if($name == "rahim"){
    get_header();
 ?>
 
 <div class="main-area">
   <div class="container">
     <div class="row my-3" id="dashboard">
      <h3 class="py-2">Result Card</h3>
     </div>
     <div class="row">
         <!--marks card start-->
         <?php
             $id=$_GET['r'];
             $sel="SELECT * FROM final_marksheet WHERE std_id=$id";
             $Q=mysqli_query($con,$sel);
             $info=mysqli_fetch_assoc($Q);
			 $bangla=$info['std_bangla'];
			 $english=$info['std_english'];
			 $math=$info['std_math'];
			 $physics=$info['std_physics'];
			 $chemistry=$info['std_chemistry'];
         ?>
             <div class="col-md-12">
              <table class="table table-bordered">
  <thead class="thead-dark">
    <tr>
  <th class="text-center" colspan="3">Roll No: <?= $info['std_roll'];?><th>
  </tr>
  </thead>
  <tbody>
      <tr>
      <th>Subject</th>
      <th>Marks</th>
      <th>Pass/Fail</th>
    </tr>
    <tr>
      <td>Bangla</td>
      <td><?= $info['std_bangla'];?></td>
      <td><?php if($bangla > 40){echo "Pass";}else{echo "Fail";} ?></td>
    </tr>
    <tr>
      <td>English</td>
      <td><?= $info['std_english'];?></td>
	  <td><?php if($english > 40){echo "Pass";}else{echo "Fail";} ?></td>
    </tr>
    <tr>
      <td>Math</td>
      <td><?= $info['std_math'];?></td>
	  <td><?php if($math > 40){echo "Pass";}else{echo "Fail";} ?></td>
    </tr>
	<tr>
      <td>Physics</td>
      <td><?= $info['std_physics'];?></td>
	  <td><?php if($physics > 40){echo "Pass";}else{echo "Fail";} ?></td>
    </tr>
	<tr>
      <td>Chemistry</td>
      <td><?= $info['std_chemistry'];?></td>
	  <td><?php if($chemistry > 40){echo "Pass";}else{echo "Fail";} ?></td>
    </tr>
	<tr>
      <th>Total Marks: <?php $sum=$bangla+$english+$math+$physics+$chemistry; echo "$sum"; ?></td>
      <th>Average: <?php $average=($bangla+$english+$math+$physics+$chemistry)/5; echo "$average"; ?></td>
	  <th>Status: <?php if($bangla > 40 && $english > 40 && $math > 40 && $physics > 40 && $chemistry > 40){echo "Pass";}else{echo "Fail";} ?></td>
    </tr>
  </tbody>
</table>
             </div><!--col-md-12 end-->
			 <div class="col-md-12">
			 <a class="btn btn-sm btn-primary" href="office.php">Back</a>
			 <button onclick="window.print()" class="btn btn-sm btn-danger" type="button">PRINT</button>
			 </div>
          <!--marks card end-->
     </div>
   </div>
</div>


 
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
  </body>
</html>
	<?php } ?>