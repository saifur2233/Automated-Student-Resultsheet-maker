<?php
    require_once('functions/function.php');
    needLogged();
		$name=$_SESSION['username'];
	if($name == "karim"){
    get_header();
 ?>

<div class="main-area">
   <div class="container">
     <div class="row my-3" id="dashboard">
      <h3 class="py-2">Update Marks</h3>
     </div>
     <div class="row">
         <!--marks card start-->
         <?php
             $id=$_GET['ed'];
             $sel="SELECT * FROM stdresult WHERE std_id=$id";
             $Q=mysqli_query($con,$sel);
             $info=mysqli_fetch_assoc($Q);
             if(!empty($_POST)){
                 $eid=$_POST['eid'];
                 $bangla=$_POST['bangla'];
                 $english=$_POST['english'];
                 $math=$_POST['math'];
         		     $physics=$_POST['physics'];
         		     $chemistry=$_POST['chemistry'];

                 if(!empty($eid)){
                     $update="UPDATE stdresult SET std_bangla='$bangla',std_english='$english',std_math='$math',std_physics='$physics',std_chemistry='$chemistry' WHERE std_id='$id'";
                     if(mysqli_query($con,$update)){
                         header('Location: index.php?t='.$id);
                     }else{
                       echo "Update failed!";
                     }
                 }else{
                     echo "Please enter your name!";
                 }
             }
         ?>
             <div class="col-md-12">
             	<form class="form-horizontal" action="" method="post">
             	<div class="panel panel-primary">
                     <div class="panel-heading">
                         <div class="col-md-9 heading_title">
                             Update Marks
                          </div>
                          <div class="col-md-3 text-right">

                         </div>
                         <div class="clearfix"></div>
                     </div>
                   <div class="panel-body">
                       <div class="form-group">
                         <label for="" class="col-sm-3 control-label">Roll</label>
                         <div class="col-sm-8">
                           <input type="hidden" name="eid" value="<?= $info['std_id'];?>">
                           <input type="text" name="roll" class="form-control" value="<?= $info['std_roll'];?>" disabled>
                         </div>
                       </div>
                       <div class="form-group">
                         <label for="" class="col-sm-3 control-label">Bangla</label>
                         <div class="col-sm-8">
                           <input type="number" min="0" max="100" name="bangla" class="form-control" value="<?= $info['std_bangla'];?>">
                         </div>
                       </div>
                       <div class="form-group">
                         <label for="" class="col-sm-3 control-label">English</label>
                         <div class="col-sm-8">
                           <input type="number" min="0" max="100" class="form-control" name="english" value="<?= $info['std_english'];?>">
                         </div>
                       </div>
         			  <div class="form-group">
                         <label for="" class="col-sm-3 control-label">Math</label>
                         <div class="col-sm-8">
                           <input type="number" min="0" max="100" class="form-control" name="math" value="<?= $info['std_math'];?>">
                         </div>
                       </div>
         			  <div class="form-group">
                         <label for="" class="col-sm-3 control-label">Physics</label>
                         <div class="col-sm-8">
                           <input type="number" min="0" max="100" class="form-control" name="physics" value="<?= $info['std_physics'];?>">
                         </div>
                       </div><div class="form-group">
                         <label for="" class="col-sm-3 control-label">Chemistry</label>
                         <div class="col-sm-8">
                           <input type="number" min="0" max="100" class="form-control" name="chemistry" value="<?= $info['std_chemistry'];?>">
                         </div>
                       </div>
                   </div>
                   <div class="panel-footer text-center">
                     <button class="btn btn-sm btn-primary">UPDATE</button>
                   </div>
                 </div>
                 </form>
             </div><!--col-md-12 end-->
          <!--marks card end-->
     </div>
   </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
  </body>
</html>
	<?php } ?>