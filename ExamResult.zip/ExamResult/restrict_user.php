<?php
if(!isset($_SESSION['username']))
{
	header('location: login.php');
}
function faculty-member()
{
	if($_SESSION['username']!="karim")
	{
		header('Location: login.php');
	}
}
function director()
{
	if($_SESSION['username']!="admin")
	{
		header('Location: login.php');
	}
}

function exam-controller()
{
	if($_SESSION['username']!="rahim")
	{
		header('Location: login.php');
	}
}
?>