<?php
    require_once('functions/function.php');
    needLogged();
    $name=$_SESSION['username'];
	if($name == "karim"){
    get_header();
 ?>

<div class="main-area">
   <div class="container">
     <div class="row my-3" id="dashboard">
      <h3 class="py-2">Welcome to Teacher Panel</h3>
     </div>
     <div class="row">
       <!--left side col start-->
       <div class="col-md-6">
         <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/1.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

       </div>
       <!--left side col end-->
       <!--right side col start-->
       <div class="col-md-6">
         <div class="card">
  <div class="card-header">
    Add Marks to the Result Sheet
  </div>
  <div class="card-body">
    <form id="marksform" class="form-horizontal" role="form" method="post">
      <?php
                if(!empty($_POST)){
                    $roll=$_POST['roll'];
                    $rol= mysqli_real_escape_string($con, $roll);
                    //$bangla=$_POST['bangla'];
					$bangla= filter_input(INPUT_POST,'bangla',FILTER_SANITIZE_SPECIAL_CHARS);
                    $english=filter_input(INPUT_POST,'english',FILTER_SANITIZE_SPECIAL_CHARS);
                    $math=filter_input(INPUT_POST,'math',FILTER_SANITIZE_SPECIAL_CHARS);
                    $physics=filter_input(INPUT_POST,'physics',FILTER_SANITIZE_SPECIAL_CHARS);
                    $chemistry=filter_input(INPUT_POST,'chemistry',FILTER_SANITIZE_SPECIAL_CHARS);
                    if(!empty($roll)){

                        $insert="INSERT INTO stdresult(std_roll,std_bangla,std_english,std_math,std_physics,std_chemistry)
                        VALUES('$rol','$bangla','$english','$math','$physics','$chemistry')";
                        if(mysqli_query($con,$insert)){
                            echo "Successfull";
                        }else{
                            echo "Failed";
                        }

                    }else{
                          echo "Please, enter value";
                    }
                }
            ?>
                            <div style="margin-bottom: 20px" class="input-group">
								
                             <input type="text" maxlength="11" pattern="[A-Z 0-9 A-Z]{11}" class="form-control" name="roll" placeholder="Student Roll" required>
                            </div>
                            <div style="margin-bottom: 20px" class="input-group">
                                <input type="number" min="0" max="100" class="form-control" name="bangla" placeholder="Bangla" required>
                            </div>
                            <div style="margin-bottom: 20px" class="input-group">
                                <input type="number" min="0" max="100" class="form-control" name="english" placeholder="English" required>
                            </div>
                            <div style="margin-bottom: 20px" class="input-group">
                                <input type="number" min="0" max="100" class="form-control" name="math" placeholder="Math" required>
                            </div>
                            <div style="margin-bottom: 20px" class="input-group">
                                <input type="number" min="0" max="100" class="form-control" name="physics" placeholder="Physics" required>
                            </div>
                            <div style="margin-bottom: 20px" class="input-group">
                                <input type="number" min="0" max="100" class="form-control" name="chemistry" placeholder="Chemistry" required>
                            </div>
                            <div style="margin-top:10px" class="form-group">
                                <!-- Button -->
                                <div class="col-sm-12 controls">
                                    <button id="btn-login" class="btn btn-success">Submit </button>
                                </div>
                            </div>
                        </form>
  </div>
</div>
       </div>
     </div>
     <div class="row my-3" id="dashboard">
      <h3 class="py-2">View Mark Sheet</h3>
     </div>
     <!--marks list show-->
<div class="card">
  <div class="card-header">Marks Sheet</div>
  <div class="card-body">
   <!---->
   <table class="table table-responsive table-striped table-hover table_cus">
         <thead class="table_head">
           <tr>
               <th>Roll</th>
               <th>Bangla</th>
               <th>English</th>
               <th>Math</th>
               <th>Physics</th>
               <th>Chemistry</th>
               <th>Edit marks</th>
               <th>Feedback</th>
           </tr>
         </thead>
           <tbody>
             <?php
                 $sel="SELECT * FROM stdresult ORDER BY std_id DESC";
                 $Q=mysqli_query($con,$sel);
                 while($data=mysqli_fetch_assoc($Q)){
             ?>
             <tr>
                 <td><?= $data['std_roll']; ?></td>
                 <td><?= $data['std_bangla']; ?></td>
                 <td><?= $data['std_english']; ?></td>
                 <td><?= $data['std_math']; ?></td>
                 <td><?= $data['std_physics']; ?></td>
                 <td><?= $data['std_chemistry']; ?></td>
                 <td>
                     <a href="edit.php?ed=<?=$data['std_id'] ?>"><i class="fa fa-pencil-square-o fa-lg"></i></a>
                 </td>
                 <td><?= $data['feedback']; ?></td>
               </tr>
               <?php } ?>
           </tbody>
     </table>
   <!---->
  </div>
</div>
<!--end-->
   </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
  </body>
</html>
	<?php } ?>