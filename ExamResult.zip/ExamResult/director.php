<?php
    require_once('functions/function.php');
    needLogged();
	//include('restrict_user.php');
	//director();
	$name=$_SESSION['username'];
	if($name == "admin"){
    get_header();
 ?>
<div class="main-area">
   <div class="container">
     <div class="row my-3" id="dashboard">
      <h3 class="py-2">Welcome <?php echo "$position"; ?> to Director Panel</h3>
     </div>
     <div class="row">
       <div class="col-md-12">
         <!--marks card start-->
         <div class="card">
           <div class="card-header"> <h4 class="text-center text-info">Pendding Result Sheet</h4> </div>
           <div class="card-body">
            <!---->
            <table class="table table-responsive table-striped table-hover table_cus">
              		<thead class="table_head">
                		<tr>
                      	<th>Roll</th>
                        <th>Bangla</th>
                        <th>English</th>
                        <th>Math</th>
                        <th>Physics</th>
                        <th>Chemistry</th>
                        <th>Feedback</th>
                        <th>Approve</th>
                    </tr>
                	</thead>
                    <tbody>
                      <?php
                          $sel="SELECT * FROM stdresult ORDER BY std_id DESC";
                          $Q=mysqli_query($con,$sel);
                          while($data=mysqli_fetch_assoc($Q)){
                      ?>
                    	<tr>
                        	<td><?= $data['std_roll']; ?></td>
                          <td><?= $data['std_bangla']; ?></td>
                          <td><?= $data['std_english']; ?></td>
                          <td><?= $data['std_math']; ?></td>
                          <td><?= $data['std_physics']; ?></td>
                          <td><?= $data['std_chemistry']; ?></td>
                          <td><?= substr($data['feedback'],0,20);?>...</td>
                          <td>
                              <a href="approve.php?a=<?= $data['std_id']; ?>"><i class="fa fa-check-square fa-lg"></i></a>
                              <a href="feedback.php?fed=<?= $data['std_id']; ?>"><i class="fa fa-commenting-o fa-lg"></i></a>
                              <a href="delete.php?del=<?= $data['std_id']; ?>"><i class="fa fa-trash fa-lg"></i></a>
                          </td>
                        </tr>
                        <?php } ?>
                    </tbody>
              </table>
            <!---->
           </div>
         </div>
          <!--marks card end-->
       </div>
     </div>
   </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
  </body>
</html>
	<?php } ?>