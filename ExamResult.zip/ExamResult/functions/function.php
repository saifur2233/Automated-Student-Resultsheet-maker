<?php
    session_start();
    require_once('config.php');
    function get_validatelogin(){
      require_once('validatelogin.php');
    }
    function get_matching(){
      require_once('matching.php');
    }
    function get_header(){
      require_once('includes/header.php');
    }
    function getLoggedID(){
        return $_SESSION['id'] ? true:false;
    }

    function needLogged(){
        $check=getLoggedID();
        if(!$check){
            header('Location: login.php');
        }
    }
 ?>
